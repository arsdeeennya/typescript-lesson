const person = {
  name: 'Peter'
}
export = person