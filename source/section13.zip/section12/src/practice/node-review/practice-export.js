module.exports.hello = 'hello'
exports.name = 'Peter';