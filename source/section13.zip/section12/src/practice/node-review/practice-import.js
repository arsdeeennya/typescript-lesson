const practice = require('./practice-export');
console.log(practice);