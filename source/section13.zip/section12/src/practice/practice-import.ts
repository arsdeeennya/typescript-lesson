import * as practice from './practice-export';
// import practice = require('./practice-export');
console.log(practice);