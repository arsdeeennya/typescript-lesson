import { Foods } from "./foods";
Foods.getInstance();
